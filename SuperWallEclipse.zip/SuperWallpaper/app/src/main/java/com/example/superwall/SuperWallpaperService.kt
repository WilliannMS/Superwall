package com.example.superwall

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Shader
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.service.wallpaper.WallpaperService
import android.view.Choreographer
import android.view.SurfaceHolder
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

private const val WAKE_MS = 1100L      // tela ligando
private const val UNLOCK_MS = 1600L    // transição de desbloqueio
private const val PARTICLES = 40

private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t
private fun clamp01(x: Float) = if (x < 0f) 0f else if (x > 1f) 1f else x
private fun easeInOut(t: Float): Float {
    val x = clamp01(t)
    return if (x < 0.5f) 4f * x * x * x else 1f - (-2f * x + 2f).pow(3) / 2f
}
private fun easeOut(t: Float): Float {
    val x = 1f - clamp01(t)
    return 1f - x * x * x
}

class SuperWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = SuperEngine()

    private enum class Mode { LOCKED, WAKING, UNLOCKING, UNLOCKED }

    private inner class SuperEngine : Engine(), SensorEventListener, Choreographer.FrameCallback {

        private var visible = false
        private var mode = Mode.LOCKED
        private var modeStart = -1L
        private var lastDraw = 0L
        private var lastDt = 0L

        private var w = 0
        private var h = 0
        private var bitmap: Bitmap? = null
        private val base = Matrix()

        private val imgPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG or Paint.DITHER_FLAG)
        private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.SCREEN)
        }
        private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.SCREEN)
        }
        private val ringColors = IntArray(4)
        private val ringPos = FloatArray(4)

        // partículas de poeira de luz
        private val rnd = Random(7)
        private val px = FloatArray(PARTICLES)
        private val py = FloatArray(PARTICLES)
        private val pvx = FloatArray(PARTICLES)
        private val pvy = FloatArray(PARTICLES)
        private val psz = FloatArray(PARTICLES)
        private val pph = FloatArray(PARTICLES)
        private val pspd = FloatArray(PARTICLES)

        // inclinação (parallax)
        private var sensorManager: SensorManager? = null
        private var baseX = 0f
        private var baseY = 0f
        private var targetX = 0f
        private var targetY = 0f
        private var tiltX = 0f
        private var tiltY = 0f

        private val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                when (intent.action) {
                    Intent.ACTION_SCREEN_OFF -> setMode(Mode.LOCKED)
                    Intent.ACTION_SCREEN_ON ->
                        if (isKeyguardLocked()) setMode(Mode.WAKING) else setMode(Mode.UNLOCKED)
                    Intent.ACTION_USER_PRESENT ->
                        if (mode != Mode.UNLOCKED && mode != Mode.UNLOCKING) setMode(Mode.UNLOCKING)
                }
            }
        }

        private fun isKeyguardLocked(): Boolean {
            val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            return km.isKeyguardLocked
        }

        private fun setMode(m: Mode) {
            mode = m
            modeStart = -1L
        }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            bitmap = BitmapFactory.decodeResource(resources, R.drawable.wallpaper_base)
            for (i in 0 until PARTICLES) {
                px[i] = rnd.nextFloat()
                py[i] = rnd.nextFloat()
                pvx[i] = (rnd.nextFloat() - 0.5f) * 0.006f
                pvy[i] = -(0.004f + rnd.nextFloat() * 0.012f)
                psz[i] = 0.7f + rnd.nextFloat() * 1.6f
                pph[i] = rnd.nextFloat() * 6.28f
                pspd[i] = 0.6f + rnd.nextFloat() * 1.4f
            }
            mode = if (isPreview || isKeyguardLocked()) Mode.LOCKED else Mode.UNLOCKED

            val f = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_USER_PRESENT)
            }
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
            } else {
                registerReceiver(receiver, f)
            }
            sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        }

        override fun onDestroy() {
            visible = false
            Choreographer.getInstance().removeFrameCallback(this)
            try { unregisterReceiver(receiver) } catch (_: Exception) {}
            sensorManager?.unregisterListener(this)
            bitmap?.recycle()
            bitmap = null
            super.onDestroy()
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            w = width
            h = height
            val bmp = bitmap ?: return
            val s = max(w.toFloat() / bmp.width, h.toFloat() / bmp.height)
            base.reset()
            base.postScale(s, s)
            base.postTranslate((w - bmp.width * s) / 2f, (h - bmp.height * s) / 2f)
        }

        override fun onVisibilityChanged(v: Boolean) {
            visible = v
            val choreo = Choreographer.getInstance()
            choreo.removeFrameCallback(this)
            if (v) {
                if (!isPreview && mode == Mode.UNLOCKED && isKeyguardLocked()) setMode(Mode.LOCKED)
                val acc = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
                if (acc != null) sensorManager?.registerListener(this, acc, SensorManager.SENSOR_DELAY_GAME)
                lastDt = 0L
                choreo.postFrameCallback(this)
            } else {
                sensorManager?.unregisterListener(this)
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            Choreographer.getInstance().removeFrameCallback(this)
            super.onSurfaceDestroyed(holder)
        }

        // ---------- sensor ----------
        override fun onSensorChanged(e: SensorEvent) {
            val x = e.values[0]
            val z = e.values[2]
            baseX += (x - baseX) * 0.01f
            baseY += (z - baseY) * 0.01f
            targetX = ((x - baseX) / 3f).coerceIn(-1f, 1f)
            targetY = ((z - baseY) / 3f).coerceIn(-1f, 1f)
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

        // ---------- loop ----------
        override fun doFrame(frameTimeNanos: Long) {
            if (!visible) return
            val now = frameTimeNanos / 1_000_000L
            val idle = mode == Mode.LOCKED || mode == Mode.UNLOCKED
            if (!idle || now - lastDraw >= 30L) {
                lastDraw = now
                draw(now)
            }
            Choreographer.getInstance().postFrameCallback(this)
        }

        private fun draw(now: Long) {
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockHardwareCanvas()
                if (canvas != null) render(canvas, now)
            } catch (_: Exception) {
            } finally {
                if (canvas != null) {
                    try { holder.unlockCanvasAndPost(canvas) } catch (_: Exception) {}
                }
            }
        }

        // ---------- helpers de desenho ----------
        private fun drawImage(
            c: Canvas, sc: Float, rot: Float, ox: Float, oy: Float,
            tx: Float, ty: Float, alpha: Int
        ) {
            val bmp = bitmap ?: return
            c.save()
            c.translate(ox + tx, oy + ty)
            c.rotate(rot)
            c.scale(sc, sc)
            c.translate(-ox, -oy)
            imgPaint.alpha = alpha
            c.drawBitmap(bmp, base, imgPaint)
            c.restore()
        }

        private fun drawGlow(c: Canvas, cx: Float, cy: Float, r: Float, a: Float) {
            if (a <= 0.004f) return
            val a8 = (clamp01(a) * 255).toInt()
            glowPaint.shader = RadialGradient(
                cx, cy, r, Color.argb(a8, 235, 238, 245), Color.argb(0, 235, 238, 245),
                Shader.TileMode.CLAMP
            )
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), glowPaint)
        }

        private fun drawRing(c: Canvas, cx: Float, cy: Float, r: Float, wd: Float, a: Float) {
            if (a <= 0.004f) return
            val rr = max(r, wd + 2f)
            val outer = rr + wd
            val clear = Color.argb(0, 255, 255, 255)
            ringColors[0] = clear
            ringColors[1] = clear
            ringColors[2] = Color.argb((clamp01(a) * 255).toInt(), 255, 255, 255)
            ringColors[3] = clear
            ringPos[0] = 0f
            ringPos[1] = (rr - wd) / outer
            ringPos[2] = rr / outer
            ringPos[3] = 1f
            glowPaint.shader = RadialGradient(cx, cy, outer, ringColors, ringPos, Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, outer, glowPaint)
        }

        // ---------- render ----------
        private fun render(c: Canvas, now: Long) {
            if (w == 0 || h == 0 || bitmap == null) return
            if (modeStart < 0) modeStart = now
            val el = now - modeStart
            val t = now / 1000f
            val dt = if (lastDt == 0L) 0.016f else ((now - lastDt) / 1000f).coerceIn(0f, 0.05f)
            lastDt = now

            // demo contínuo na prévia do seletor de papéis de parede
            if (isPreview) {
                if (mode == Mode.LOCKED && el > 4500L) setMode(Mode.UNLOCKING)
                else if (mode == Mode.UNLOCKED && el > 3500L) setMode(Mode.WAKING)
            }

            var wakeP = -1f
            var unlockP = -1f
            when (mode) {
                Mode.WAKING -> {
                    val q = el / WAKE_MS.toFloat()
                    if (q >= 1f) { mode = Mode.LOCKED; modeStart = now } else wakeP = q
                }
                Mode.UNLOCKING -> {
                    val q = el / UNLOCK_MS.toFloat()
                    if (q >= 1f) { mode = Mode.UNLOCKED; modeStart = now } else unlockP = q
                }
                else -> {}
            }
            val u = when {
                unlockP >= 0f -> easeInOut(unlockP)
                mode == Mode.UNLOCKED -> 1f
                else -> 0f
            }

            val wf = w.toFloat()
            val hf = h.toFloat()
            val diag = hypot(wf, hf)
            val hx = wf * 0.45f   // ponto de luz principal da imagem
            val hy = hf * 0.745f
            val dens = resources.displayMetrics.density

            tiltX += (targetX - tiltX) * 0.08f
            tiltY += (targetY - tiltY) * 0.08f
            val par = lerp(1f, 0.5f, u)

            // ----- pose da imagem -----
            val breathe = sin(t * 0.5f) * 0.012f
            var sc = lerp(1.10f + breathe, 1.55f, u)
            var rot = lerp(0f, -6f, u) + sin(t * 0.3f) * 0.4f
            val pivX = lerp(wf * 0.5f, hx, u)
            val pivY = lerp(hf * 0.5f, hy, u)
            val tx = -tiltX * wf * 0.025f * par + sin(t * 0.23f) * wf * 0.006f + lerp(0f, -wf * 0.05f, u)
            val ty = tiltY * hf * 0.015f * par + cos(t * 0.19f) * hf * 0.004f

            var bump = 0f // pico de energia da transição
            if (unlockP >= 0f) {
                val s = sin(PI.toFloat() * unlockP)
                sc += s * 0.16f                       // soco de zoom no meio
                rot += sin(2f * PI.toFloat() * unlockP) * 1.2f
                bump = s
            }
            if (wakeP >= 0f) {
                sc += (1f - easeOut(wakeP)) * 0.25f   // chega de longe
                bump = sin(PI.toFloat() * wakeP) * 0.5f
            }

            c.drawColor(Color.BLACK)
            drawImage(c, sc, rot, pivX, pivY, tx, ty, 255)

            // rastro de zoom (motion blur radial) no desbloqueio
            if (unlockP >= 0f) {
                val m = sin(PI.toFloat() * unlockP)
                for (k in 1..3) {
                    drawImage(c, sc * (1f + 0.035f * k * m), rot, pivX, pivY, tx, ty, (80 - k * 18).coerceAtLeast(10))
                }
            }

            // escurece no estado desbloqueado (ícones legíveis)
            val dim = lerp(0f, 0.45f, u)
            if (dim > 0.01f) c.drawColor(Color.argb((dim * 255).toInt(), 0, 0, 0))

            // luz que desliza pela curva
            val gx = hx + sin(t * 0.35f) * wf * 0.14f
            val gy = hy + cos(t * 0.27f) * hf * 0.012f
            val glowA = lerp(0.16f + 0.06f * sin(t * 0.8f), 0.07f, u) + bump * 0.18f
            drawGlow(c, gx, gy, wf * 0.6f, glowA)

            // poeira de luz
            val push = u * 0.12f * hf
            for (i in 0 until PARTICLES) {
                px[i] += pvx[i] * dt
                py[i] += pvy[i] * dt * (1f + bump * 3f)
                if (py[i] < -0.05f) { py[i] = 1.05f; px[i] = rnd.nextFloat() }
                if (px[i] < -0.05f) px[i] = 1.05f
                if (px[i] > 1.05f) px[i] = -0.05f
                var bx = px[i] * wf
                var by = py[i] * hf
                val dx = bx - hx
                val dy = by - hy
                val d = hypot(dx, dy) + 1f
                val p2 = push * (0.5f + psz[i] * 0.4f)
                bx += dx / d * p2
                by += dy / d * p2
                val tw = 0.5f + 0.5f * sin(t * pspd[i] + pph[i])
                val a = (0.05f + 0.20f * tw) * (1f - 0.4f * u) * (1f + 2.5f * bump)
                dotPaint.color = Color.argb((clamp01(a) * 255).toInt(), 255, 255, 255)
                c.drawCircle(bx, by, psz[i] * dens, dotPaint)
            }

            // ondas de choque + clarão no desbloqueio
            if (unlockP >= 0f) {
                val p = unlockP
                val r1 = easeOut(p) * diag * 1.05f
                drawRing(c, hx, hy, r1, diag * 0.07f, 0.55f * (1f - p).pow(1.5f))
                val p2 = (p - 0.12f) / 0.88f
                if (p2 > 0f) {
                    val r2 = easeOut(p2) * diag * 1.05f
                    drawRing(c, hx, hy, r2, diag * 0.05f, 0.35f * (1f - p2).pow(1.5f))
                }
                val f0 = max(0f, 1f - abs(p - 0.3f) / 0.3f)
                val flash = f0 * f0 * (3f - 2f * f0)
                drawGlow(c, hx, hy, diag * 0.85f, 0.55f * flash)
            }

            // ao ligar a tela: emerge do preto
            if (wakeP >= 0f) {
                val a = 1f - easeOut(clamp01(wakeP * 1.5f))
                c.drawColor(Color.argb((a * 255).toInt(), 0, 0, 0))
            }
        }
    }
}
